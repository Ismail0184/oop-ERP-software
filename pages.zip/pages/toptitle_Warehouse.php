<?php
require_once 'support_file.php';
require_once 'dashboard_data.php';
?>



<h1 style="text-align:center; margin-top:200px">Welcome to <?=find_a_field('warehouse','warehouse_name','warehouse_id='.$_SESSION['warehouse']);?></h1>
      
