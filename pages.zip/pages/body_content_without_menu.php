<body class="nav-md">
<div class="container body">
<div class="main_container">
<div class="top_nav"></div>
<div class="right_col" role="main">
<div class="">
<div class="row">