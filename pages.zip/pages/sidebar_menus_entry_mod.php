<div class="menu_section">
                <h3></h3>
                <ul class="nav side-menu">
                <li><a href="dashboard.php"><i class="fa fa-home"></i>
                        <?php
if($_SESSION['language']=='Bangla') {?>মেনু দেখতে এখানে ক্লিক করুন
                        <?php } else if($_SESSION['language']=='English') { ?>
                        Click here to see menus
                    <?php } ?></a></li></ul><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
                </div>
           
            
