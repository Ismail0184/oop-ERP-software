<?php require_once ('support_file.php');?>

              <div class="menu_section">
                <h3></h3>
                <ul class="nav side-menu">
                    <li><a href="dashboard.php"><i class="fa fa-home"></i>Home</a></li>

                    <li><a href="#"><i class="fa fa-industry"></i>Company <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="developer_create_company.php">Create Company</a></li>
                            <li><a href="developer_create_warehouse.php">Create Warehouse</a></li>
                        </ul>
                    </li>

                    <li><a href="#"><i class="fa fa-pencil-square-o"></i>Module Builder <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="developer_create_module.php">Create Module</a></li>
                            <li><a href="developer_module_create_main.php">Create Main Menu</a></li>
                            <li><a href="developer_module_create_sub.php">Create Sub Menu</a></li>
                            <li><a href="developer_module_create_other_options.php">Create Meta Data</a></li>
                        </ul>
                    </li>

                    <li><a href="#"><i class="fa fa-pencil-square-o"></i>Report Builder <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="developer_optgroup_label.php">Optgroup Label</a></li>
                            <li><a href="developer_report.php">Report</a></li>
                        </ul>
                    </li>

                    <li><a href="#"><i class="fa fa-database"></i>Database Tools<span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="#">Maintenance</a></li>
                            <li><a href="developer_database_backup.php">Backup</a></li>
                        </ul>
                    </li>
                </ul></div>
           
            
